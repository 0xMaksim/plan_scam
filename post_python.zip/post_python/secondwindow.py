from PyQt6.QtWidgets import *
#from PyQt6.QtCore import *
import sys
from models import session
from sqlalchemy import text


class SecondWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("SecondWindow")
        self.setFixedSize(700, 500)
        tb_lt = QVBoxLayout()
        self.table = QTableWidget()
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(["Логин", "Пароль"])
        
        sql_count = text("select count(*) from public.auth")
        obj_count = session.execute(sql_count)
        for row in obj_count:
            self.table.setRowCount(row[0])
            
        sql = text("select login, password from public.auth")   
        obj = session.execute(sql)
        
        x = -1
        for row in obj:
            x +=1
            
            y = -1
            for i in row:
                y +=1 
                self.table.setItem(x, y, QTableWidgetItem(i))
        
        
        
        with open("pycss.css", "r") as css:
            self.setStyleSheet(css.read())
        
        self.search_edit = QLineEdit()
        search_button = QPushButton("Поиск")
        search_button.clicked.connect(self.search_clicked)
        
        
        tb_lt.addWidget(self.table)
        tb_lt.addWidget(self.search_edit)
        tb_lt.addWidget(search_button)
             
        widget = QWidget()
        widget.setLayout(tb_lt)
        self.setCentralWidget(widget)
        
    def search_clicked(self):
        self.table.clear()
        sql_search = text(f"select login, password from public.auth where login = '"+self.search_edit.text()+"'")
        obj_search = session.execute(sql_search)
        x = -1
        for row in obj_search:
            x +=1
            
            y = -1
            for i in row:
                y +=1 
                self.table.setItem(x, y, QTableWidgetItem(i))    
        
        
        
app = QApplication(sys.argv)
window = SecondWindow()
window.show()
app.exec()
    
        
        