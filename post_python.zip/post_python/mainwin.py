from PyQt6.QtWidgets import *
#from PyQt6.QtCore import *
import sys
from models import session
from sqlalchemy import text
from secondwindow import SecondWindow


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("MainWindow")
        self.setFixedSize(400, 300)
        layout = QVBoxLayout()
        log_label = QLabel("Логин")
        password_label = QLabel("Пароль")
        
        self.log_edit = QLineEdit()
        self.password_edit = QLineEdit()
        
        self.message = QMessageBox()
        self.mess_label = QLabel()
        
        self.log_edit.setText("user")
        self.password_edit.setText("user")
        
        log_button = QPushButton()
        log_button.setText("Войти")
        log_button.clicked.connect(self.login_clicked)
        
        exit_button = QPushButton()
        exit_button.setText("Выход")
        exit_button.clicked.connect(self.exit_clicked)
        
        layout.addWidget(log_label)
        layout.addWidget(self.log_edit)
        layout.addWidget(password_label)
        layout.addWidget(self.password_edit)
        layout.addWidget(log_button)
        layout.addWidget(exit_button)
        layout.addWidget(self.mess_label)
        
        widget = QWidget()
        widget.setLayout(layout)
        self.setCentralWidget(widget)
        
        self.secondwin = SecondWindow()
        
        with open("pycss.css", "r") as css:
            self.setStyleSheet(css.read())
            
        
    
    def login_clicked(self):
        sql = text("SELECT * FROM public.auth")
        obj = session.execute(sql)
        
        for row in obj:
            for login in row:
                for password in row:
                    if self.log_edit.text() == login and self.password_edit.text() == password:
                        self.mess_label.setText("Добро пожаловать")
                        self.secondwin.show()
                        self.close()
                    else:
                        self.mess_label.setText("Неверный логин или пароль")    
                        
    
    def exit_clicked(self):
        self.close()  
        
           
        
    
app = QApplication(sys.argv)
window = MainWindow()
window.show()
app.exec()



# if self.log_edit.text() == "admin" and self.password_edit.text() == "admin":
#             self.message.setText("Мега харош")
#             self.message.exec()
            
#         else:
#             self.mess_label.setText("Ah shit, here we go again")
        
        