from sqlalchemy import text
from models import session

sql = text("INSERT INTO public.auth(login, password)VALUES ('sus', 'impostor')")
obj = session.execute(sql)

session.commit()
session.close()
