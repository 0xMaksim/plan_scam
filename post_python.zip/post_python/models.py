from sqlalchemy import Column, Integer, String, create_engine, Identity, ForeignKey
from sqlalchemy.orm import declarative_base, Session
import psycopg2 

engin = create_engine("postgresql+psycopg2://postgres:postgres@localhost/test_skd")

Base = declarative_base()

session = Session(bind=engin)

class Auth(Base):
    __tablename__ = 'auth'
    id = Column(Integer, Identity(True), primary_key=True)
    login = Column(String, nullable=False)
    password = Column(String, nullable=False)

class Doljnost(Base):
    __tablename__ = 'doljnost'
    id = Column(Integer, Identity(True), primary_key=True)
    name = Column(String, nullable=False)
    authId = Column(Integer, ForeignKey('auth.id'), nullable=False)
    
Base.metadata.create_all(engin)    